class_name ScanIndicator
extends Control
## Small circular cooldown ring for the scanner, with the key label in the middle.

var ratio := 1.0:
	set(value):
		ratio = clampf(value, 0.0, 1.0)
		queue_redraw()
var key_text := "Q"


func _draw() -> void:
	var c := size * 0.5
	var r := minf(size.x, size.y) * 0.5 - 4.0
	draw_circle(c, r + 3.0, Color(0.07, 0.08, 0.11, 0.7))
	draw_arc(c, r, 0.0, TAU, 48, Color(1, 1, 1, 0.12), 4.0, true)
	if ratio < 1.0:
		draw_arc(c, r, -PI * 0.5, -PI * 0.5 + TAU * ratio, 48, Color(0.45, 0.93, 1.0, 0.9), 4.0, true)
	else:
		draw_arc(c, r, 0.0, TAU, 48, Color(0.45, 0.93, 1.0, 0.55), 3.0, true)
	var font := get_theme_default_font()
	var fs := 18
	var ts := font.get_string_size(key_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	draw_string(font, c - Vector2(ts.x * 0.5, -fs * 0.35), key_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(0.97, 0.94, 0.87, 0.95 if ratio >= 1.0 else 0.5))
