extends Node3D
## Main menu over a small living diorama: the robot hovering among giant flowers while the
## camera drifts slowly around it.

const DIORAMA_CENTER := Vector3.ZERO

var _camera: Camera3D
var _robot: RobotVisual
var _time := 0.0
var _buttons: VBoxContainer
var _continue: Button
var _new_game: Button
var _settings: SettingsPanel
var _confirm: PanelContainer
var _menu_panel: Control
var _summary: Label


func _ready() -> void:
	GameState.in_gameplay = false
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_build_diorama()
	_build_ui()
	Audio.stop_all_ambient(1.0)
	Audio.play_music(&"menu", 2.5)
	Audio.set_ambient(&"meadow_base", 0.6, 3.0, -10.0)


func _process(delta: float) -> void:
	_time += delta
	var a := _time * 0.06
	var pos := Vector3(sin(a) * 4.4, 1.35 + sin(_time * 0.3) * 0.15, cos(a) * 4.4 + 0.5)
	_camera.look_at_from_position(pos, Vector3(0.6, 0.65, 0))


# --- Diorama ------------------------------------------------------------------------

func _build_diorama() -> void:
	var env := WorldEnvironment.new()
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-32, -40, 0)
	add_child(sun)
	var atmo := AtmosphereController.new()
	add_child(atmo)
	atmo.setup(env, sun)
	atmo.set_restoration(&"meadow", 1.0)
	atmo.environment.fog_density = 0.02
	atmo.environment.ssao_enabled = true
	RenderingServer.global_shader_parameter_set(&"restore_levels", Vector4(1, 1, 1, 1))
	RenderingServer.global_shader_parameter_set(&"player_position", Vector3(0, -100, 0))
	var focus := Node3D.new()
	add_child(focus)
	atmo.focus = focus

	var ground := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(80, 80)
	plane.subdivide_width = 1
	plane.subdivide_depth = 1
	ground.mesh = plane
	var ground_mat := StandardMaterial3D.new()
	ground_mat.albedo_color = Color(0.36, 0.5, 0.2)
	ground_mat.roughness = 1.0
	ground.material_override = ground_mat
	add_child(ground)

	_robot = RobotVisual.new()
	add_child(_robot)
	_robot.position = Vector3(0.6, 0.0, 0.0)
	_robot.rotation.y = deg_to_rad(200)
	_robot.set_locomotion(0.0, 0.0)

	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var flowers := ["daisy_a", "daisy_pink", "tulip_a", "bluebell_a", "daisy_b", "sunflower", "dandelion_a"]
	for i in 26:
		var a := rng.randf() * TAU
		var r := rng.randf_range(3.2, 16.0)
		var kind: String = flowers[rng.randi() % flowers.size()]
		var p := PropLibrary.place(self, kind, Vector3(cos(a) * r, 0, sin(a) * r - 3.0), rng.randf() * 360.0, rng.randf_range(0.6, 1.1), false)
		p.name = "Flower%d" % i
	for i in 380:
		var a := rng.randf() * TAU
		var r := sqrt(rng.randf()) * 18.0 + 1.2
		var g := PropLibrary.instance("grass_a" if rng.randf() < 0.6 else "grass_b")
		add_child(g)
		g.position = Vector3(cos(a) * r, 0, sin(a) * r)
		g.rotation.y = rng.randf() * TAU
		g.scale = Vector3.ONE * rng.randf_range(0.7, 1.3)
		if g is MeshInstance3D:
			(g as MeshInstance3D).material_override = PropLibrary.material("grass")
	PropLibrary.place(self, "rock_moss_a", Vector3(-2.6, -0.4, -1.6), 40.0, 0.6, false)
	PropLibrary.place(self, "mushroom_cluster", Vector3(2.4, 0, -1.8), 0.0, 0.8, false)
	PropLibrary.place(self, "charging_station", Vector3(-1.6, 0, 1.2), 150.0, 1.0, false)
	add_child(FxFactory.ambient_motes(Color(1.0, 0.95, 0.75, 0.8), 60, Vector3(8, 2.5, 8), 0.06, 0.08))

	_camera = Camera3D.new()
	_camera.fov = 52.0
	_camera.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	add_child(_camera)
	_camera.make_current()


# --- UI -------------------------------------------------------------------------

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(root)
	var shade := ColorRect.new()
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var grad := ShaderMaterial.new()
	grad.shader = preload("res://shaders/menu_vignette.gdshader")
	shade.material = grad
	root.add_child(shade)

	_menu_panel = VBoxContainer.new()
	_menu_panel.anchor_top = 0.5
	_menu_panel.anchor_bottom = 0.5
	_menu_panel.offset_left = 110
	_menu_panel.offset_top = -300
	_menu_panel.offset_right = 760
	_menu_panel.offset_bottom = 340
	(_menu_panel as VBoxContainer).add_theme_constant_override("separation", 10)
	root.add_child(_menu_panel)
	var title := Label.new()
	title.theme_type_variation = &"TitleLabel"
	title.text = "Little Bot,\nBig World"
	_menu_panel.add_child(title)
	var tagline := Label.new()
	tagline.theme_type_variation = &"HintLabel"
	tagline.text = "A tiny robot. An enormous, sleeping garden."
	tagline.add_theme_font_size_override("font_size", 22)
	_menu_panel.add_child(tagline)
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 26)
	_menu_panel.add_child(spacer)
	_buttons = VBoxContainer.new()
	_buttons.add_theme_constant_override("separation", 10)
	_buttons.custom_minimum_size = Vector2(360, 0)
	_buttons.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_menu_panel.add_child(_buttons)
	var summary := SaveSystem.read_summary()
	_continue = _button("Continue", _on_continue)
	_continue.visible = not summary.is_empty()
	_summary = Label.new()
	_summary.theme_type_variation = &"HintLabel"
	_summary.add_theme_font_size_override("font_size", 17)
	if not summary.is_empty():
		var minutes := int(float(summary["play_time"]) / 60.0)
		_summary.text = "   %s  ·  %d energy  ·  %dh %02dm" % [GameData.area_name(summary["area"]), summary["energy"], minutes / 60, minutes % 60]
	_summary.visible = not summary.is_empty()
	_buttons.add_child(_summary)
	_new_game = _button("New Game", _on_new_game)
	_button("Settings", _on_settings)
	_button("Quit", func() -> void: get_tree().quit())
	var footer := Label.new()
	footer.theme_type_variation = &"HintLabel"
	footer.add_theme_font_size_override("font_size", 15)
	footer.text = "Made with Godot %s" % Engine.get_version_info()["string"].split(".stable")[0]
	footer.anchor_top = 1.0
	footer.anchor_bottom = 1.0
	footer.offset_left = 110
	footer.offset_top = -56
	root.add_child(footer)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	_settings = SettingsPanel.new()
	_settings.visible = false
	center.add_child(_settings)
	_settings.closed.connect(_show_menu)
	_confirm = _build_confirm()
	center.add_child(_confirm)
	UiSounds.wire(root)
	(_continue if _continue.visible else _new_game).grab_focus.call_deferred()


func _button(text: String, action: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.theme_type_variation = &"MenuButtonBig"
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.pressed.connect(action)
	_buttons.add_child(b)
	return b


func _build_confirm() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.theme_type_variation = &"CardPanel"
	panel.visible = false
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	panel.add_child(box)
	var label := Label.new()
	label.text = "Start a new journey?\nYour current progress will be replaced."
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(label)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_child(row)
	var yes := Button.new()
	yes.text = "Start new game"
	yes.pressed.connect(_start_new)
	row.add_child(yes)
	var no := Button.new()
	no.name = "Cancel"
	no.text = "Keep my progress"
	no.pressed.connect(_show_menu)
	row.add_child(no)
	return panel


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and _confirm.visible:
		_show_menu()


func _show_menu() -> void:
	_settings.visible = false
	_confirm.visible = false
	_menu_panel.visible = true
	(_continue if _continue.visible else _new_game).grab_focus.call_deferred()


func _on_continue() -> void:
	SceneRouter.continue_game()


func _on_new_game() -> void:
	if SaveSystem.has_save():
		_menu_panel.visible = false
		_confirm.visible = true
		(_confirm.find_child("Cancel", true, false) as Button).grab_focus.call_deferred()
	else:
		_start_new()


func _start_new() -> void:
	SceneRouter.start_new_game()


func _on_settings() -> void:
	_menu_panel.visible = false
	_settings.open()
