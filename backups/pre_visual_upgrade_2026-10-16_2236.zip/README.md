# Little Bot, Big World

A cozy third-person exploration game built in **Godot 4.7** (GDScript, Forward+).
You play the small pink hover robot from `pink_ball_robot_with_THE_BALL_v2.blend`. It wakes
in an enormous, sleeping garden and brings it back to life, one old machine at a time.

## Running the game

1. Open the folder in Godot 4.7.x (`tools/Godot_v4.7.2-stable_win64.exe` is included), or
2. Run it directly:

```bash
tools/Godot_v4.7.2-stable_win64.exe --path .
```

The main scene is `scenes/ui/main_menu.tscn`. The first launch imports assets, which takes
about a minute.

## Controls

| Action | Keyboard / Mouse | Gamepad |
|---|---|---|
| Move | WASD / Arrow keys | Left stick |
| Look | Mouse | Right stick |
| Zoom | Mouse wheel | LB / RB |
| Hover hop (hold for higher) | Space | A |
| Boost | Shift | RT / L3 |
| Interact | E (or F) | X |
| Scan | Q | Y |
| Journal | J / Tab | Back |
| Pause | Esc | Start |

## The journey

1. **The Quiet Meadow.** Wake at the abandoned charging dock and gather energy fragments.
   Then power the old gate's pylon to raise its shutter. The meadow's flowers open and its
   colors return.
2. **The Mushroom Forest.** Giant trunks, glowing mushrooms, a hollow log into a hidden
   fairy ring. Follow old cables to three switches hidden under moss (the scanner reveals
   them), then raise the bridge over the ravine.
3. **The Forgotten Shrine.** Wake four power nodes:
   - one needs 10 energy;
   - one needs sunlight bounced off two rotating mirrors;
   - one sits behind a wall only the scanner can read;
   - one needs a broken conduit repaired by rotating stone tiles.

   Then awaken the core. Lanterns light, a waterfall starts and the great door opens.
4. **The Crystal Garden.** Wake three resonators:
   - a prism light puzzle;
   - one hidden in a humming crystal grotto;
   - a melody puzzle with singing crystals.

   Then restore the Crystal Heart (20 energy). The whole world wakes up. Afterwards you can
   keep exploring for the rest of the 30 fragments and 8 discoveries.

## Project layout

```
assets/characters/   robot GLBs exported from the .blend (+ eye-glow curves)
assets/environment/  props.glb: every environment prop, modelled by a Blender script
assets/audio/        synthesized SFX (wav), ambience/loops/music (ogg)
scenes/              world, player, levels (one per area), interactables, ui
scripts/systems/     autoloads: GameState, SaveSystem, Settings, Quests, Audio, SceneRouter, Events
scripts/player/      player controller, robot visual + AnimationTree, camera rig, interactor
scripts/gameplay/    fragments, checkpoints, devices and puzzles
scripts/world/       terrain generator, layout, grass, water, area decoration, atmosphere, director
shaders/             terrain, foliage (wind + bloom), water, crystal, sky, devices, UI
resources/           quests.json (data-driven objectives), ui_theme.tres, terrain cache
tests/               logic tests (progression, quests, save/load, level data)
tools/               asset pipeline + dev tools (see below)
```

Key ideas:

- The **robot** is the original rig. All 12 baked actions run through an AnimationTree:
  - idle, forward and lean blend space;
  - one-shot actions (poke, scan, hop, victory, bump, fidgets);
  - Shutdown played in reverse as the wake-up.

  The Blender `eye_glow` custom property is converted into an animation track, so the eyes
  flicker exactly as authored. Procedural layers add blinking, eye gaze toward interactables,
  springy antennas and body tilt.
- The **world** is one persistent scene. `WorldLayout` holds the hand-designed macro layout
  (path, areas, ravine, ponds). `WorldTerrain` generates the ground from it, with collision
  from a `HeightMapShape3D`. Area scenes place gameplay objects; their decoration scripts add
  landmarks plus rule-based scatter, batched into chunked MultiMeshes.
- **Restoration** is state-driven:
  - flags in `GameState` drive a global shader vector (`restore_levels`), so grass, flowers
    (petals fold shut while dormant), moss, mushrooms and crystals respond everywhere;
  - devices restore their own state on load.
- **Saving** is a versioned JSON file in `user://` with temp-file writes, a backup copy,
  migration and validation. Settings are stored separately in `user://settings.cfg`.

## Tools

| Command | What it does |
|---|---|
| `blender -b <file>.blend --python tools/blender/export_robots.py` | Re-export the robots from the source .blend |
| `blender -b --python tools/blender/build_props.py` | Rebuild `assets/environment/props.glb` |
| `python tools/gen_levels.py` | Regenerate the four level scenes from their layout tables |
| `python tools/audio/generate_audio.py` | Re-synthesize all audio (uses ffmpeg for ogg if present) |
| `tools/check.sh` | Import + compile-check every script |
| `godot --headless --path . res://tests/test_runner.tscn` | Logic tests |
| `tools/playtest.sh` | Automated end-to-end playthrough (windowed), screenshots in `docs/captures/` |
| `tools/capture.sh <shots.json>` | Screenshots from scripted viewpoints |

`gen_levels.py` overwrites the level scenes. If you prefer editing the levels in the Godot
editor, stop using the generator after that point.
