class_name Hud
extends CanvasLayer
## Minimal in-game HUD: objective, energy counter, contextual prompt, scan ring, toasts,
## area title cards, discovery cards, one-time control hints and cinematic letterbox.

const TOAST_TIME := 3.2

var player: Player
## Forces a specific prompt (e.g. "Wake up" before the robot is awake). Empty clears it.
var forced_prompt := ""

var _objective_panel: PanelContainer
var _objective_label: Label
var _energy_box: Control
var _energy_label: Label
var _energy_icon: EnergyIcon
var _prompt_panel: PanelContainer
var _prompt_key: Label
var _prompt_key_panel: PanelContainer
var _prompt_text: Label
var _scan: ScanIndicator
var _toasts: VBoxContainer
var _banner: Control
var _banner_title: Label
var _banner_sub: Label
var _discovery: PanelContainer
var _discovery_title: Label
var _discovery_text: Label
var _hint_panel: PanelContainer
var _hint_label: RichTextLabel
var _save_label: Label
var _letter_top: ColorRect
var _letter_bottom: ColorRect
var _root: Control
var _shown_hints: Dictionary = {}
var _objective_fade_timer := 0.0
var _hud_visible := true
var _prompt_target: Interactable


func _ready() -> void:
	layer = 10
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)
	_build_letterbox()
	_build_objective()
	_build_energy()
	_build_prompt()
	_build_scan()
	_build_toasts()
	_build_banner()
	_build_discovery()
	_build_hint()
	GameState.fragment_collected.connect(_on_fragment)
	Quests.objective_changed.connect(_on_objective_changed)
	Quests.objective_progress.connect(func(_id: StringName, text: String) -> void: _set_objective(text, false))
	Quests.objective_completed.connect(_on_objective_completed)
	Events.notify.connect(show_toast)
	Events.area_banner.connect(show_area_banner)
	Events.discovery_shown.connect(show_discovery)
	SaveSystem.saved.connect(_on_saved)
	_set_objective(Quests.current_text(), false)
	_energy_label.text = str(GameState.energy())


func _input(event: InputEvent) -> void:
	InputGlyphs.observe(event)


func _process(delta: float) -> void:
	if player:
		_scan.ratio = player.scan_ready_ratio
		_scan.key_text = InputGlyphs.label("scan")
		_update_prompt()
	if _objective_fade_timer > 0.0 and _hud_visible:
		_objective_fade_timer -= delta
		if _objective_fade_timer <= 0.0:
			var tween := create_tween()
			tween.tween_property(_objective_panel, "modulate:a", 0.55, 1.5)


# --- Layout ---------------------------------------------------------------------

func _build_letterbox() -> void:
	_letter_top = ColorRect.new()
	_letter_top.color = Color(0, 0, 0, 1)
	_letter_top.anchor_right = 1.0
	_letter_top.offset_bottom = 0.0
	_letter_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_letter_top)
	_letter_bottom = ColorRect.new()
	_letter_bottom.color = Color(0, 0, 0, 1)
	_letter_bottom.anchor_top = 1.0
	_letter_bottom.anchor_right = 1.0
	_letter_bottom.anchor_bottom = 1.0
	_letter_bottom.offset_top = 0.0
	_letter_bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_letter_bottom)


func _build_objective() -> void:
	_objective_panel = PanelContainer.new()
	_objective_panel.theme_type_variation = &"SoftPanel"
	_objective_panel.position = Vector2(36, 32)
	_objective_panel.custom_minimum_size = Vector2(0, 0)
	_objective_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_objective_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	_objective_panel.add_child(box)
	var cap := Label.new()
	cap.theme_type_variation = &"CaptionLabel"
	cap.text = "CURRENT GOAL"
	box.add_child(cap)
	_objective_label = Label.new()
	_objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_objective_label.custom_minimum_size = Vector2(420, 0)
	_objective_label.add_theme_font_size_override("font_size", 21)
	box.add_child(_objective_label)


func _build_energy() -> void:
	_energy_box = PanelContainer.new()
	_energy_box.theme_type_variation = &"SoftPanel"
	_energy_box.anchor_left = 1.0
	_energy_box.anchor_right = 1.0
	_energy_box.offset_left = -190
	_energy_box.offset_right = -36
	_energy_box.offset_top = 32
	_energy_box.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_energy_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_energy_box)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_END
	_energy_box.add_child(row)
	_energy_icon = EnergyIcon.new()
	_energy_icon.custom_minimum_size = Vector2(34, 40)
	row.add_child(_energy_icon)
	_energy_label = Label.new()
	_energy_label.theme_type_variation = &"EnergyLabel"
	_energy_label.text = "0"
	row.add_child(_energy_label)
	var total := Label.new()
	total.theme_type_variation = &"HintLabel"
	total.text = "/ %d" % GameData.total_fragments()
	total.size_flags_vertical = Control.SIZE_SHRINK_END
	row.add_child(total)
	_save_label = Label.new()
	_save_label.theme_type_variation = &"HintLabel"
	_save_label.text = "Saved"
	_save_label.anchor_left = 1.0
	_save_label.anchor_right = 1.0
	_save_label.offset_left = -190
	_save_label.offset_right = -40
	_save_label.offset_top = 96
	_save_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_save_label.modulate.a = 0.0
	_root.add_child(_save_label)


func _build_prompt() -> void:
	_prompt_panel = PanelContainer.new()
	_prompt_panel.theme_type_variation = &"SoftPanel"
	_prompt_panel.anchor_left = 0.5
	_prompt_panel.anchor_right = 0.5
	_prompt_panel.anchor_top = 1.0
	_prompt_panel.anchor_bottom = 1.0
	_prompt_panel.offset_top = -132
	_prompt_panel.offset_bottom = -132
	_prompt_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_prompt_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_prompt_panel.modulate.a = 0.0
	_root.add_child(_prompt_panel)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	_prompt_panel.add_child(row)
	_prompt_key_panel = PanelContainer.new()
	var key_style := StyleBoxFlat.new()
	key_style.bg_color = Color(0.97, 0.94, 0.87)
	key_style.set_corner_radius_all(7)
	key_style.content_margin_left = 10
	key_style.content_margin_right = 10
	key_style.content_margin_top = 2
	key_style.content_margin_bottom = 2
	_prompt_key_panel.add_theme_stylebox_override("panel", key_style)
	_prompt_key_panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_prompt_key_panel.custom_minimum_size = Vector2(34, 30)
	row.add_child(_prompt_key_panel)
	_prompt_key = Label.new()
	_prompt_key.theme_type_variation = &"KeyLabel"
	_prompt_key.text = "E"
	_prompt_key.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt_key.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_prompt_key_panel.add_child(_prompt_key)
	_prompt_text = Label.new()
	_prompt_text.text = ""
	_prompt_text.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(_prompt_text)


func _build_scan() -> void:
	_scan = ScanIndicator.new()
	_scan.anchor_left = 1.0
	_scan.anchor_right = 1.0
	_scan.anchor_top = 1.0
	_scan.anchor_bottom = 1.0
	_scan.offset_left = -100
	_scan.offset_right = -40
	_scan.offset_top = -100
	_scan.offset_bottom = -40
	_scan.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_scan)


func _build_toasts() -> void:
	_toasts = VBoxContainer.new()
	_toasts.anchor_top = 1.0
	_toasts.anchor_bottom = 1.0
	_toasts.offset_left = 36
	_toasts.offset_top = -260
	_toasts.offset_bottom = -40
	_toasts.offset_right = 560
	_toasts.alignment = BoxContainer.ALIGNMENT_END
	_toasts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_toasts)


func _build_banner() -> void:
	_banner = VBoxContainer.new()
	_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_banner.offset_top = 150
	_banner.offset_left = -500
	_banner.offset_right = 500
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.modulate.a = 0.0
	(_banner as VBoxContainer).alignment = BoxContainer.ALIGNMENT_CENTER
	_root.add_child(_banner)
	_banner_sub = Label.new()
	_banner_sub.theme_type_variation = &"CaptionLabel"
	_banner_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner_sub.add_theme_font_size_override("font_size", 18)
	_banner.add_child(_banner_sub)
	_banner_title = Label.new()
	_banner_title.theme_type_variation = &"TitleLabel"
	_banner_title.add_theme_font_size_override("font_size", 56)
	_banner_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner.add_child(_banner_title)
	var line := ColorRect.new()
	line.color = Color(0.97, 0.94, 0.87, 0.5)
	line.custom_minimum_size = Vector2(220, 2)
	line.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_banner.add_child(line)


func _build_discovery() -> void:
	_discovery = PanelContainer.new()
	_discovery.theme_type_variation = &"CardPanel"
	_discovery.anchor_left = 1.0
	_discovery.anchor_right = 1.0
	_discovery.anchor_top = 0.5
	_discovery.anchor_bottom = 0.5
	_discovery.offset_left = -520
	_discovery.offset_right = -40
	_discovery.offset_top = -90
	_discovery.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_discovery.modulate.a = 0.0
	_root.add_child(_discovery)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	_discovery.add_child(box)
	var cap := Label.new()
	cap.theme_type_variation = &"CaptionLabel"
	cap.text = "DISCOVERY"
	cap.add_theme_color_override("font_color", Color(1.0, 0.85, 0.55))
	box.add_child(cap)
	_discovery_title = Label.new()
	_discovery_title.theme_type_variation = &"HeaderLabel"
	box.add_child(_discovery_title)
	_discovery_text = Label.new()
	_discovery_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_discovery_text.custom_minimum_size = Vector2(420, 0)
	_discovery_text.add_theme_font_size_override("font_size", 20)
	box.add_child(_discovery_text)


func _build_hint() -> void:
	_hint_panel = PanelContainer.new()
	_hint_panel.theme_type_variation = &"SoftPanel"
	_hint_panel.anchor_left = 0.5
	_hint_panel.anchor_right = 0.5
	_hint_panel.anchor_top = 1.0
	_hint_panel.anchor_bottom = 1.0
	_hint_panel.offset_top = -64
	_hint_panel.offset_bottom = -64
	_hint_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_hint_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_hint_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hint_panel.modulate.a = 0.0
	_root.add_child(_hint_panel)
	_hint_label = RichTextLabel.new()
	_hint_label.bbcode_enabled = true
	_hint_label.fit_content = true
	_hint_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	_hint_label.scroll_active = false
	_hint_label.add_theme_font_size_override("normal_font_size", 19)
	_hint_label.add_theme_font_size_override("bold_font_size", 19)
	_hint_panel.add_child(_hint_label)


# --- Public API ---------------------------------------------------------------

func set_hud_visible(value: bool, duration: float = 0.5) -> void:
	_hud_visible = value
	if value:
		_objective_fade_timer = 9.0
	var tween := create_tween().set_parallel(true)
	for node: CanvasItem in [_objective_panel, _energy_box, _scan, _prompt_panel]:
		tween.tween_property(node, "modulate:a", (1.0 if node != _prompt_panel else 0.0) if value else 0.0, duration)


func set_letterbox(on: bool, duration: float = 0.8) -> void:
	var h := 90.0 if on else 0.0
	var tween := create_tween().set_parallel(true).set_trans(Tween.TRANS_SINE)
	tween.tween_property(_letter_top, "offset_bottom", h, duration)
	tween.tween_property(_letter_bottom, "offset_top", -h, duration)


func show_toast(text: String, kind: String = "info") -> void:
	var panel := PanelContainer.new()
	panel.theme_type_variation = &"SoftPanel"
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var row := HBoxContainer.new()
	panel.add_child(row)
	var dot := ColorRect.new()
	dot.custom_minimum_size = Vector2(6, 22)
	dot.color = {"energy": Color(0.45, 0.93, 1.0), "save": Color(0.7, 1.0, 0.7), "locked": Color(1.0, 0.7, 0.5),
		"discovery": Color(1.0, 0.85, 0.55)}.get(kind, Color(0.97, 0.94, 0.87, 0.7))
	row.add_child(dot)
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 20)
	row.add_child(label)
	panel.modulate.a = 0.0
	_toasts.add_child(panel)
	while _toasts.get_child_count() > 3:
		var old := _toasts.get_child(0)
		_toasts.remove_child(old)
		old.queue_free()
	var tween := panel.create_tween()
	tween.tween_property(panel, "modulate:a", 1.0, 0.3)
	tween.tween_interval(TOAST_TIME)
	tween.tween_property(panel, "modulate:a", 0.0, 0.6)
	tween.tween_callback(panel.queue_free)


func show_area_banner(area_id: StringName) -> void:
	var index := GameData.AREA_IDS.find(area_id)
	_banner_sub.text = ["I", "II", "III", "IV"][maxi(index, 0)] if index >= 0 else ""
	_banner_title.text = GameData.area_name(area_id)
	var tween := create_tween()
	tween.tween_property(_banner, "modulate:a", 1.0, 1.2)
	tween.tween_interval(2.6)
	tween.tween_property(_banner, "modulate:a", 0.0, 1.6)


func show_discovery(discovery_id: StringName) -> void:
	var entry := GameData.discovery(discovery_id)
	if entry.is_empty():
		return
	_discovery_title.text = entry["title"]
	_discovery_text.text = entry["text"]
	_discovery.offset_left = -480
	var tween := create_tween()
	tween.tween_property(_discovery, "modulate:a", 1.0, 0.5)
	tween.parallel().tween_property(_discovery, "offset_left", -520.0, 0.5).set_trans(Tween.TRANS_SINE)
	tween.tween_interval(5.5)
	tween.tween_property(_discovery, "modulate:a", 0.0, 0.8)


## Shows a control hint once per id, e.g. ("move", "[b]WASD[/b] move   [b]Mouse[/b] look").
func show_hint(id: String, bbcode: String, duration: float = 6.0) -> void:
	if _shown_hints.has(id):
		return
	_shown_hints[id] = true
	_hint_label.text = "[center]%s[/center]" % bbcode
	var tween := create_tween()
	tween.tween_property(_hint_panel, "modulate:a", 1.0, 0.5)
	tween.tween_interval(duration)
	tween.tween_property(_hint_panel, "modulate:a", 0.0, 0.8)


func has_shown_hint(id: String) -> bool:
	return _shown_hints.has(id)


func _update_prompt() -> void:
	var target: Interactable = player.interactor.current if player and player.input_enabled else null
	var text := ""
	var locked := false
	if forced_prompt != "":
		text = forced_prompt
	elif target != null and _hud_visible:
		text = target.get_prompt()
		locked = target.locked
	var visible_now := text != ""
	_prompt_key.text = InputGlyphs.label("interact")
	_prompt_key_panel.visible = not locked
	if visible_now:
		_prompt_text.text = text
		_prompt_text.modulate = Color(1, 1, 1, 0.65) if locked else Color(1, 1, 1, 1)
	var target_alpha := 1.0 if visible_now else 0.0
	_prompt_panel.modulate.a = move_toward(_prompt_panel.modulate.a, target_alpha, get_process_delta_time() * 6.0)


func _set_objective(text: String, highlight: bool) -> void:
	_objective_label.text = text
	_objective_panel.visible = text != ""
	if not _hud_visible:
		return
	if highlight:
		_objective_panel.modulate.a = 1.0
		var tween := create_tween()
		_objective_panel.position.x = 16
		tween.tween_property(_objective_panel, "position:x", 36.0, 0.5).set_trans(Tween.TRANS_BACK)
	else:
		_objective_panel.modulate.a = maxf(_objective_panel.modulate.a, 0.85)
	_objective_fade_timer = 9.0


func _on_objective_changed(_id: StringName, text: String) -> void:
	_set_objective(text, true)


func _on_objective_completed(_id: StringName) -> void:
	Audio.play_sfx(&"objective", -6.0)


func _on_fragment(_id: StringName, total: int) -> void:
	_energy_label.text = str(total)
	var tween := create_tween()
	_energy_box.pivot_offset = _energy_box.size * 0.5
	tween.tween_property(_energy_box, "scale", Vector2.ONE * 1.15, 0.12)
	tween.tween_property(_energy_box, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK)
	tween.parallel().tween_method(func(v: float) -> void: _energy_icon.pulse = v, 1.0, 0.0, 0.9)


func _on_saved() -> void:
	var tween := create_tween()
	tween.tween_property(_save_label, "modulate:a", 0.8, 0.3)
	tween.tween_interval(1.2)
	tween.tween_property(_save_label, "modulate:a", 0.0, 0.8)
